import { handler } from "./index.js";
const main = async () => {
    const event = {};
    const result = await handler(event, {}, () => { });
    console.log("Resultado:", result);
};
main().catch(console.error);
//# sourceMappingURL=local.js.map