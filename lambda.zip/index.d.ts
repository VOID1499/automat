import type { Handler } from "aws-lambda";
export declare const handler: Handler;
//# sourceMappingURL=index.d.ts.map